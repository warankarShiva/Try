package com.demoaut.newtours.constants;

public interface IConstants {

	public static final String CHROMEDRIVERPATH = "test-artifacts//Drivers//Mac//chromedriver";
	public static final int IMPLICITWAITSTND=30;
	public static final String CHROME = "CHROME";
	
}
