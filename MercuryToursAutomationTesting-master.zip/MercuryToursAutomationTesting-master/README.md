# MercuryToursAutomationTesting
## This project is intended for performing an automated functional test of Flight Reservations on [Mercury Tours](http://newtours.demoaut.com) 
Key Features :
- Selenium WebDriver and Java Bindings
- Page Object Model
- Extent reports & logs
- Scalable testing framework
